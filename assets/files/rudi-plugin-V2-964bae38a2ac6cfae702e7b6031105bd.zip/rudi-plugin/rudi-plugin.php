<?php
/**
 * Plugin Name:   Rudi by Animuz
 * Description:   Embedded custom ChatGPT for your business
 * Version:       0.10.0
 * Author:        Datability Co., Ltd.
 * Author URI:    https://datability.info/
 * Plugin URI:    https://rudi.animuz.ai/
 * License:       GPL v2 or later
 * License URI:   https://www.gnu.org/licenses/gpl-2.0.html
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

if ( ! class_exists( 'RudiByAnimuzPlugin' ) ) {
    class RudiByAnimuzPlugin {
        public static function init() {
            // register_setting( 'rudi_settings', 'rudi_option_foo' );
            // add_action('init', 'rudi_callback_run_me_normal');
            
            /**
             * Register our rudi_settings_init to the admin_init action hook.
             */
            add_action( 'admin_init', 'rudi_settings_init' );
            /**
             * Register our rudi_menu_page to the admin_menu action hook.
             */
            add_action( 'admin_menu', "RudiByAnimuzPlugin::rudi_menu_page" );

            // Display the header scripts in head
            add_action( 'wp_head', 'rudi_display_header_scripts' );
        }

        public static function get_foo() {
            // return get_option( 'rudi_option_foo' );
        }
        /**  Add the top level menu page. */
        public static function rudi_menu_page() {
            add_menu_page(
                'Rudi by Animuz', // Page Title
                'Rudi Options',   // Menu Title
                'manage_options', // Capability
                'rudi',          // Menu Slug
                'rudi_options_page_html', // Callback function
                'dashicons-pets',  // Icon URL
                200                // Position
            );
        }
    }

    RudiByAnimuzPlugin::init();
}

/**
 * Top level menu callback function
 */
function rudi_options_page_html() {
	// check user capabilities
	if ( ! current_user_can( 'manage_options' ) ) {
		return;
	}
	// add error/update messages
	// check if the user have submitted the settings
	// WordPress will add the "settings-updated" $_GET parameter to the url
	if ( isset( $_GET['settings-updated'] ) ) {
		// add settings saved message with the class of "updated"
		add_settings_error( 'rudi_messages', 'rudi_message', __( 'Settings Saved', 'rudi' ), 'updated' );
	}
	// show error/update messages
	settings_errors( 'rudi_messages' );
	?>
	<div class="wrap">
		<h1><?php echo esc_html( get_admin_page_title() ); ?></h1>
		<form action="options.php" method="post">
			<?php
			// output security fields for the registered setting "rudi"
			settings_fields( 'rudi' );
			// output setting sections and their fields
			// (sections are registered for "rudi", each field is registered to a specific section)
			do_settings_sections( 'rudi' );
			// output save settings button
			submit_button( 'Save Settings' );
			?>
		</form>
	</div>
	<?php
}

function rudi_display_header_scripts() {
    $options = get_option( 'rudi_options' );
    $script = $options['rudi_embed_script'];
    echo $script;
}


function rudi_callback_run_me_normal() {
    // echo '<div class="notice notice-success is-dismissible"><p>Callback is working!</p></div>';
    debug_to_console('Callback is working!');
}

function debug_to_console($data) {
    $output = $data;
    if (is_array($output))
        $output = implode(',', $output);

    echo "<script>console.log('Debug Objects: " . $output . "' );</script>";
}


/* asdpokasdpokpasodk */
/**
 * @internal never define functions inside callbacks.
 * these functions could be run multiple times; this would result in a fatal error.
 */

/**
 * Rudi option and settings
 */
function rudi_settings_init() {
	// Register a new setting for "rudi" page.
	register_setting( 'rudi', 'rudi_options' );    

    

	// Register a new section in the "rudi" page.
	add_settings_section(
		'rudi_section_developers',
		__( 'Settings', 'rudi' ), 'rudi_section_developers_callback',
		'rudi'
	);

    add_settings_field(
        'rudi_embed_script',
        'Embed Script',
        'rudi_embed_script_cb',
        'rudi',
        'rudi_section_developers',
        array(
            'label_for'         => 'rudi_embed_script',
            'class'             => 'rudi_row',
        )
    );

	// Register a new field in the "rudi_section_developers" section, inside the "rudi" page.
	// add_settings_field(
	// 	'rudi_field_pill', // As of WP 4.6 this value is used only internally.
	// 	                        // Use $args' label_for to populate the id inside the callback.
	// 		__( 'Pill', 'rudi' ),
	// 	'rudi_field_pill_cb',
	// 	'rudi',
	// 	'rudi_section_developers',
	// 	array(
	// 		'label_for'         => 'rudi_field_pill',
	// 		'class'             => 'rudi_row',
	// 		'rudi_custom_data' => 'custom',
	// 	)
	// );
}


function rudi_embed_script_cb( $args ) {
	// Get the value of the setting we've registered with register_setting()
	$options = get_option( 'rudi_options' );
	?>
	<textarea 
		id="<?php echo esc_attr( $args['label_for'] ); ?>"
		name="rudi_options[<?php echo esc_attr( $args['label_for'] ); ?>]"
        rows="7"
        cols="100"
        placeholder="Paste your script here"
        required
    ><?php echo isset( $options[ $args['label_for'] ] ) ? (  htmlentities($options[ $args['label_for'] ]) ) : ( '' ); ?></textarea>
	<?php
}


/**
 * Developers section callback function.
 *
 * @param array $args  The settings array, defining title, id, callback.
 */
function rudi_section_developers_callback( $args ) {
	?>
	<p id="<?php echo esc_attr( $args['id'] ); ?>"><?php esc_html_e( 'Setup your rudi with rudi.animuz.ai and paste your embedded script here.', 'rudi' ); ?></p>
	<?php
}

/**
 * Pill field callbakc function.
 *
 * WordPress has magic interaction with the following keys: label_for, class.
 * - the "label_for" key value is used for the "for" attribute of the <label>.
 * - the "class" key value is used for the "class" attribute of the <tr> containing the field.
 * Note: you can add custom key value pairs to be used inside your callbacks.
 *
 * @param array $args
 */
function rudi_field_pill_cb( $args ) {
	// Get the value of the setting we've registered with register_setting()
	$options = get_option( 'rudi_options' );
	?>
	<select
			id="<?php echo esc_attr( $args['label_for'] ); ?>"
			data-custom="<?php echo esc_attr( $args['rudi_custom_data'] ); ?>"
			name="rudi_options[<?php echo esc_attr( $args['label_for'] ); ?>]">
		<option value="red" <?php echo isset( $options[ $args['label_for'] ] ) ? ( selected( $options[ $args['label_for'] ], 'red', false ) ) : ( '' ); ?>>
			<?php esc_html_e( 'red pill', 'rudi' ); ?>
		</option>
 		<option value="blue" <?php echo isset( $options[ $args['label_for'] ] ) ? ( selected( $options[ $args['label_for'] ], 'blue', false ) ) : ( '' ); ?>>
			<?php esc_html_e( 'blue pill', 'rudi' ); ?>
		</option>
	</select>
	<?php
}


?>